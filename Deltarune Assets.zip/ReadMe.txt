Deltarune Assets

Arranged by Aspen (TisTangoTime) :3
All assets sourced from the Deltarune game files


--- [ V1.0 Changelog ] ---
    - [ 23/07/2025 ] -

   Version notes: 
> Initial release

   Character changes:
> Added Kris sprites (14D/1L) & animations (57D/19L)
> Added Susie sprites (25D/5L), animations (55D/36L), & portraits (72)
> Added Ralsei sprites (4c1/43c2+), animations (18c1/80c2+), & portraits (18c1/53c2+)
> Added Noelle sprites (2D/2L) & animations (28D/12L)
> Added Berdly sprites (19D/1L) & animations (16D/10L)
> Added Tenna sprite (1) & animations (13)
> Added some NPC sprites (30) & animations (58)
  ^ Annoying Dog (0s/4a)
  ^ Jack (12s)
  ^ Lancer (4s/7a)
  ^ Mr Elegance (4s)
  ^ Mr Society (2s)
  ^ Starwalker (1s/1a)
  ^ Topchef (1a)
  ^ Alphys (8a)
  ^ Asgore (4s/21a)
  ^ Catty (2s/2a)
  ^ Sans (6a)
  ^ Toriel (1s/7a)
  ^ Undyne (1a)

   Text changes:
> Added "TV Time" text (8)

-----

https://www.youtube.com/watch?v=u5NqO2v_xnY